import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../utils/colors.dart';
import '../widgets/custom_drawer.dart';
import 'equipment/equipment_list_screen.dart';
import 'workers/workers_list_screen.dart';
import 'land/land_list_screen.dart';
import 'supplies/supplies_list_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _selectedIndex = 0;

  final List<Widget> _screens = [
    const HomeContent(),
    const EquipmentListScreen(),
    const WorkersListScreen(),
    const LandListScreen(),
    const SuppliesListScreen(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'منصة الفلاح',
          style: GoogleFonts.cairo(fontWeight: FontWeight.bold),
        ),
      ),
      drawer: const CustomDrawer(),
      body: _screens[_selectedIndex],
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _selectedIndex,
        onTap: (index) {
          setState(() => _selectedIndex = index);
        },
        items: const [
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            label: 'الرئيسية',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.agriculture),
            label: 'المعدات',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.people),
            label: 'العمال',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.landscape),
            label: 'الأراضي',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.local_pharmacy),
            label: 'الأدوية',
          ),
        ],
      ),
    );
  }
}

class HomeContent extends StatelessWidget {
  const HomeContent({super.key});

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: AppColors.primary,
              borderRadius: BorderRadius.circular(16),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'أهلاً بك في منصة الفلاح',
                  style: GoogleFonts.cairo(
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                    color: AppColors.white,
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  'منصة زراعية متكاملة للفلاح الجزائري',
                  style: GoogleFonts.cairo(
                    fontSize: 14,
                    color: AppColors.white.withAlpha(204), // Recommended way to set opacity
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 24),
          Text(
            'الأقسام الرئيسية',
            style: GoogleFonts.cairo(
              fontSize: 18,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 16),
          GridView.count(
            crossAxisCount: 2,
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            mainAxisSpacing: 16,
            crossAxisSpacing: 16,
            children: [
              _buildCategoryCard(
                context,
                'المعدات الزراعية',
                Icons.agriculture,
                AppColors.primary,
                () => Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => const EquipmentListScreen(),
                  ),
                ),
              ),
              _buildCategoryCard(
                context,
                'العمال',
                Icons.people,
                AppColors.secondary,
                () => Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => const WorkersListScreen(),
                  ),
                ),
              ),
              _buildCategoryCard(
                context,
                'الأراضي',
                Icons.landscape,
                AppColors.accent,
                () => Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => const LandListScreen(),
                  ),
                ),
              ),
              _buildCategoryCard(
                context,
                'الأدوية والأسمدة',
                Icons.local_pharmacy,
                Colors.green,
                () => Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => const SuppliesListScreen(),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildCategoryCard(
    BuildContext context,
    String title,
    IconData icon,
    Color color,
    VoidCallback onTap,
  ) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        decoration: BoxDecoration(
          color: color.withAlpha(25), // Recommended way to set opacity
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: color, width: 2),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, size: 48, color: color),
            const SizedBox(height: 12),
            Text(
              title,
              style: GoogleFonts.cairo(
                fontSize: 14,
                fontWeight: FontWeight.bold,
                color: color,
              ),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }
}
