import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../models/land_model.dart';
import '../../utils/colors.dart';
import 'add_land_screen.dart';

class LandListScreen extends StatefulWidget {
  const LandListScreen({super.key});

  @override
  State<LandListScreen> createState() => _LandListScreenState();
}

class _LandListScreenState extends State<LandListScreen> {
  final List<LandModel> _landList = [
    LandModel(
      id: '1',
      name: 'أرض زراعية خصبة',
      type: 'أرض صالحة للزراعة',
      area: 5.0,
      price: 500000,
      wilaya: 'سطيف',
      commune: 'سطيف',
      description: 'أرض خصبة وصالحة للزراعة',
      sellerId: 'seller1',
      sellerName: 'أحمد محمد',
      images: [],
      rating: 4.6,
      reviewsCount: 8,
      createdAt: DateTime.now(),
      soilType: 'تربة سوداء',
      hasWater: true,
    ),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'الأراضي',
          style: GoogleFonts.cairo(fontWeight: FontWeight.bold),
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => const AddLandScreen(),
            ),
          );
        },
        backgroundColor: AppColors.primary,
        child: const Icon(Icons.add),
      ),
      body: ListView.builder(
        padding: const EdgeInsets.all(16),
        itemCount: _landList.length,
        itemBuilder: (context, index) {
          final land = _landList[index];
          return _buildLandCard(land);
        },
      ),
    );
  }

  Widget _buildLandCard(LandModel land) {
    return Card(
      margin: const EdgeInsets.only(bottom: 16),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              width: double.infinity,
              height: 200,
              decoration: BoxDecoration(
                color: AppColors.lightGrey,
                borderRadius: BorderRadius.circular(12),
              ),
              child:
                  const Icon(Icons.landscape, size: 80, color: AppColors.grey),
            ),
            const SizedBox(height: 12),
            Text(
              land.name,
              style: GoogleFonts.cairo(
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 8),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  '${land.area} هكتار',
                  style: GoogleFonts.cairo(
                    fontSize: 14,
                    color: AppColors.grey,
                  ),
                ),
                Text(
                  land.soilType,
                  style: GoogleFonts.cairo(
                    fontSize: 14,
                    color: AppColors.grey,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 8),
            Row(
              children: [
                const Icon(Icons.water_drop, color: Colors.blue, size: 16),
                const SizedBox(width: 4),
                Text(
                  land.hasWater ? 'يوجد ماء' : 'لا يوجد ماء',
                  style: GoogleFonts.cairo(fontSize: 12),
                ),
              ],
            ),
            const SizedBox(height: 12),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  '${land.price} دج',
                  style: GoogleFonts.cairo(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                    color: AppColors.primary,
                  ),
                ),
                ElevatedButton(
                  onPressed: () {},
                  style: ElevatedButton.styleFrom(
                    backgroundColor: AppColors.primary,
                  ),
                  child: Text(
                    'التفاصيل',
                    style: GoogleFonts.cairo(color: AppColors.white),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
