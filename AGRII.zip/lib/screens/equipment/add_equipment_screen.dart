import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'dart:io';
import '../../utils/colors.dart';
import '../../utils/constants.dart';
import '../../widgets/location_selector.dart';
import '../../widgets/image_picker_widget.dart';
import '../../providers/equipment_provider.dart';
import '../../providers/auth_provider.dart';
import '../../models/equipment_model.dart';
import '../../services/storage_service.dart';

class AddEquipmentScreen extends StatefulWidget {
  const AddEquipmentScreen({super.key});

  @override
  State<AddEquipmentScreen> createState() => _AddEquipmentScreenState();
}

class _AddEquipmentScreenState extends State<AddEquipmentScreen> {
  final _nameController = TextEditingController();
  final _descriptionController = TextEditingController();
  final _priceController = TextEditingController();
  final StorageService _storageService = StorageService();

  String _selectedType = AppConstants.equipmentTypes[0];
  String _selectedWilaya = '';
  String _selectedCommune = '';
  bool _forRent = false;
  bool _forSale = true;
  bool _isLoading = false;
  List<File> _selectedImages = [];

  @override
  void dispose() {
    _nameController.dispose();
    _descriptionController.dispose();
    _priceController.dispose();
    super.dispose();
  }

  Future<void> _addEquipment() async {
    final name = _nameController.text.trim();
    final description = _descriptionController.text.trim();
    final priceStr = _priceController.text.trim();

    if (name.isEmpty ||
        description.isEmpty ||
        priceStr.isEmpty ||
        _selectedWilaya.isEmpty ||
        _selectedCommune.isEmpty ||
        _selectedImages.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('يرجى ملء جميع الحقول المطلوبة واختيار صورة واحدة على الأقل')),
      );
      return;
    }

    if (!_forRent && !_forSale) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('يرجى اختيار نوع العرض (إيجار أو بيع)')),
      );
      return;
    }

    setState(() => _isLoading = true);

    try {
      final authProvider = Provider.of<AuthProvider>(context, listen: false);
      final equipmentProvider = Provider.of<EquipmentProvider>(context, listen: false);
      
      // 1. رفع الصور إلى Firebase Storage
      List<String> imageUrls = await _storageService.uploadMultipleImages(_selectedImages, 'equipment');

      // 2. إنشاء كائن المعدة
      final equipment = EquipmentModel(
        id: DateTime.now().millisecondsSinceEpoch.toString(),
        name: name,
        description: description,
        type: _selectedType,
        price: double.parse(priceStr),
        forRent: _forRent,
        forSale: _forSale,
        wilaya: _selectedWilaya,
        commune: _selectedCommune,
        sellerId: authProvider.currentUser?.id ?? 'anonymous',
        sellerName: authProvider.currentUser?.name ?? 'مستخدم',
        images: imageUrls,
        createdAt: DateTime.now(),
      );

      // 3. حفظ البيانات في Firestore
      bool success = await equipmentProvider.addEquipment(equipment);

      if (success) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('تم إضافة المعدة بنجاح')),
          );
          Navigator.pop(context);
        }
      } else {
        throw Exception('فشل في إضافة المعدة إلى قاعدة البيانات');
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('حدث خطأ: $e')),
        );
      }
    } finally {
      if (mounted) {
        setState(() => _isLoading = false);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'إضافة معدة جديدة',
          style: GoogleFonts.cairo(fontWeight: FontWeight.bold),
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text(
              'معلومات المعدة',
              style: GoogleFonts.cairo(
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 16),
            TextField(
              controller: _nameController,
              decoration: InputDecoration(
                hintText: 'اسم المعدة *',
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                filled: true,
                fillColor: AppColors.white,
              ),
            ),
            const SizedBox(height: 16),
            DropdownButtonFormField<String>(
              value: _selectedType,
              decoration: InputDecoration(
                hintText: 'نوع المعدة *',
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                filled: true,
                fillColor: AppColors.white,
              ),
              items: AppConstants.equipmentTypes
                  .map((type) => DropdownMenuItem(
                        value: type,
                        child: Text(type, style: GoogleFonts.cairo()),
                      ))
                  .toList(),
              onChanged: (value) {
                setState(() =>
                    _selectedType = value ?? AppConstants.equipmentTypes[0]);
              },
            ),
            const SizedBox(height: 16),
            TextField(
              controller: _descriptionController,
              maxLines: 4,
              decoration: InputDecoration(
                hintText: 'وصف المعدة *',
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                filled: true,
                fillColor: AppColors.white,
              ),
            ),
            const SizedBox(height: 16),
            TextField(
              controller: _priceController,
              keyboardType: TextInputType.number,
              decoration: InputDecoration(
                hintText: 'السعر (دج) *',
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                filled: true,
                fillColor: AppColors.white,
              ),
            ),
            const SizedBox(height: 24),
            ImagePickerWidget(
              onImagesSelected: (images) {
                setState(() => _selectedImages = images);
              },
            ),
            const SizedBox(height: 24),
            Text(
              'الموقع',
              style: GoogleFonts.cairo(
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 16),
            LocationSelector(
              onWilayaChanged: (wilaya) {
                setState(() => _selectedWilaya = wilaya);
              },
              onCommuneChanged: (commune) {
                setState(() => _selectedCommune = commune);
              },
            ),
            const SizedBox(height: 24),
            Text(
              'نوع العرض',
              style: GoogleFonts.cairo(
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 16),
            CheckboxListTile(
              title: Text('للإيجار', style: GoogleFonts.cairo()),
              value: _forRent,
              onChanged: (value) {
                setState(() => _forRent = value ?? false);
              },
            ),
            CheckboxListTile(
              title: Text('للبيع', style: GoogleFonts.cairo()),
              value: _forSale,
              onChanged: (value) {
                setState(() => _forSale = value ?? false);
              },
            ),
            const SizedBox(height: 24),
            ElevatedButton(
              onPressed: _isLoading ? null : _addEquipment,
              style: ElevatedButton.styleFrom(
                backgroundColor: AppColors.primary,
                padding: const EdgeInsets.symmetric(vertical: 16),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
              child: _isLoading
                  ? const SizedBox(
                      height: 20,
                      width: 20,
                      child: CircularProgressIndicator(
                        valueColor:
                            AlwaysStoppedAnimation<Color>(AppColors.white),
                        strokeWidth: 2,
                      ),
                    )
                  : Text(
                      'إضافة المعدة',
                      style: GoogleFonts.cairo(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                        color: AppColors.white,
                      ),
                    ),
            ),
            const SizedBox(height: 20),
          ],
        ),
      ),
    );
  }
}