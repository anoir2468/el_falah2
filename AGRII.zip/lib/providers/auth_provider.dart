import 'package:flutter/material.dart';
import '../models/user_model.dart';
import '../services/auth_service.dart';

class AuthProvider extends ChangeNotifier {
  final AuthService _authService = AuthService();
  UserModel? _currentUser;
  bool _isLoading = false;
  String? _errorMessage;

  UserModel? get currentUser => _currentUser;
  bool get isLoading => _isLoading;
  String? get errorMessage => _errorMessage;
  bool get isAuthenticated => _currentUser != null;

  // تهيئة المستخدم عند تشغيل التطبيق
  Future<void> initializeUser() async {
    _isLoading = true;
    notifyListeners();
    _currentUser = await _authService.getCurrentUserModel();
    _isLoading = false;
    notifyListeners();
  }

  Future<bool> register({
    required String email,
    required String password,
    required String name,
    required String phone,
    required String wilaya,
    required String commune,
    required String userType,
  }) async {
    _isLoading = true;
    _errorMessage = null;
    notifyListeners();

    try {
      UserModel? user = await _authService.registerUser(
        email: email,
        password: password,
        name: name,
        phone: phone,
        wilaya: wilaya,
        commune: commune,
        userType: userType,
      );

      if (user != null) {
        _currentUser = user;
        _isLoading = false;
        notifyListeners();
        return true;
      }
    } catch (e) {
      _errorMessage = _handleAuthError(e);
      print('خطأ في التسجيل: $e');
    }

    _isLoading = false;
    notifyListeners();
    return false;
  }

  Future<bool> login({
    required String email,
    required String password,
  }) async {
    _isLoading = true;
    _errorMessage = null;
    notifyListeners();

    try {
      UserModel? user = await _authService.loginUser(
        email: email,
        password: password,
      );

      if (user != null) {
        _currentUser = user;
        _isLoading = false;
        notifyListeners();
        return true;
      }
    } catch (e) {
      _errorMessage = _handleAuthError(e);
      print('خطأ في تسجيل الدخول: $e');
    }

    _isLoading = false;
    notifyListeners();
    return false;
  }

  Future<void> logout() async {
    await _authService.logoutUser();
    _currentUser = null;
    notifyListeners();
  }

  String _handleAuthError(dynamic e) {
    String error = e.toString();
    if (error.contains('user-not-found')) return 'المستخدم غير موجود';
    if (error.contains('wrong-password')) return 'كلمة المرور خاطئة';
    if (error.contains('email-already-in-use')) return 'البريد الإلكتروني مستخدم بالفعل';
    if (error.contains('weak-password')) return 'كلمة المرور ضعيفة جداً';
    if (error.contains('invalid-email')) return 'البريد الإلكتروني غير صالح';
    return 'حدث خطأ ما، يرجى المحاولة لاحقاً';
  }
}
