import 'package:flutter/material.dart';
import '../models/equipment_model.dart';
import '../services/firestore_service.dart';

class EquipmentProvider extends ChangeNotifier {
  final FirestoreService _firestoreService = FirestoreService();
  List<EquipmentModel> _equipmentList = [];
  bool _isLoading = false;

  List<EquipmentModel> get equipmentList => _equipmentList;
  bool get isLoading => _isLoading;

  // جلب جميع المعدات من Firestore
  Future<void> fetchEquipment() async {
    _isLoading = true;
    notifyListeners();

    try {
      _equipmentList = await _firestoreService.getEquipment();
    } catch (e) {
      print('خطأ في جلب المعدات: $e');
    }

    _isLoading = false;
    notifyListeners();
  }

  // إضافة معدة جديدة
  Future<bool> addEquipment(EquipmentModel equipment) async {
    _isLoading = true;
    notifyListeners();
    try {
      await _firestoreService.addEquipment(equipment);
      _equipmentList.insert(0, equipment);
      _isLoading = false;
      notifyListeners();
      return true;
    } catch (e) {
      print('خطأ في إضافة المعدة: $e');
      _isLoading = false;
      notifyListeners();
      return false;
    }
  }

  // البحث حسب الولاية
  Future<void> searchByWilaya(String wilaya) async {
    _isLoading = true;
    notifyListeners();

    try {
      _equipmentList = await _firestoreService.searchEquipmentByWilaya(wilaya);
    } catch (e) {
      print('خطأ في البحث: $e');
    }

    _isLoading = false;
    notifyListeners();
  }
}
