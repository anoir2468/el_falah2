import 'package:flutter/material.dart';
import '../services/firestore_service.dart';
import '../models/supply_model.dart';

class SuppliesProvider with ChangeNotifier {
  final FirestoreService _firestoreService = FirestoreService();
  List<SupplyModel> _suppliesList = [];
  bool _isLoading = false;

  List<SupplyModel> get suppliesList => _suppliesList;
  bool get isLoading => _isLoading;

  SuppliesProvider() {
    fetchSupplies();
  }

  Future<void> fetchSupplies() async {
    _isLoading = true;
    notifyListeners();

    try {
      _suppliesList = await _firestoreService.getSupplies();
    } catch (e) {
      print('خطأ في جلب الأدوية: $e');
    }

    _isLoading = false;
    notifyListeners();
  }

  Future<void> addSupply(SupplyModel supply) async {
    _isLoading = true;
    notifyListeners();

    try {
      await _firestoreService.addSupply(supply);
      await fetchSupplies(); // Refresh the list after adding
    } catch (e) {
      print('خطأ في إضافة الدواء: $e');
    }

    _isLoading = false;
    notifyListeners();
  }

  Future<void> deleteSupply(String supplyId) async {
    _isLoading = true;
    notifyListeners();

    try {
      await _firestoreService.deleteSupply(supplyId);
      _suppliesList.removeWhere((supply) => supply.id == supplyId);
    } catch (e) {
      print('خطأ في حذف الدواء: $e');
    }

    _isLoading = false;
    notifyListeners();
  }
}
