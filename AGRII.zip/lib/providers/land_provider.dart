import 'package:flutter/material.dart';
import '../models/land_model.dart';
import '../services/firestore_service.dart';

class LandProvider extends ChangeNotifier {
  final FirestoreService _firestoreService = FirestoreService();
  List<LandModel> _landsList = [];
  bool _isLoading = false;

  List<LandModel> get landsList => _landsList;
  bool get isLoading => _isLoading;

  Future<void> fetchLands() async {
    _isLoading = true;
    notifyListeners();

    try {
      _landsList = await _firestoreService.getLands();
    } catch (e) {
      print('خطأ في جلب الأراضي: $e');
    }

    _isLoading = false;
    notifyListeners();
  }

  Future<void> addLand(LandModel land) async {
    try {
      await _firestoreService.addLand(land);
      _landsList.add(land);
      notifyListeners();
    } catch (e) {
      print('خطأ في إضافة الأرض: $e');
    }
  }
}
