class LandModel {
  final String id;
  final String name;
  final String type;
  final double area; // بالهكتار
  final double price;
  final String wilaya;
  final String commune;
  final String description;
  final String sellerId;
  final String sellerName;
  final List<String> images;
  final double rating;
  final int reviewsCount;
  final DateTime createdAt;
  final bool available;
  final String soilType;
  final bool hasWater;

  LandModel({
    required this.id,
    required this.name,
    required this.type,
    required this.area,
    required this.price,
    required this.wilaya,
    required this.commune,
    required this.description,
    required this.sellerId,
    required this.sellerName,
    required this.images,
    this.rating = 0.0,
    this.reviewsCount = 0,
    required this.createdAt,
    this.available = true,
    required this.soilType,
    required this.hasWater,
  });

  factory LandModel.fromJson(Map<String, dynamic> json) {
    return LandModel(
      id: json['id'] ?? '',
      name: json['name'] ?? '',
      type: json['type'] ?? '',
      area: (json['area'] ?? 0.0).toDouble(),
      price: (json['price'] ?? 0.0).toDouble(),
      wilaya: json['wilaya'] ?? '',
      commune: json['commune'] ?? '',
      description: json['description'] ?? '',
      sellerId: json['sellerId'] ?? '',
      sellerName: json['sellerName'] ?? '',
      images: List<String>.from(json['images'] ?? []),
      rating: (json['rating'] ?? 0.0).toDouble(),
      reviewsCount: json['reviewsCount'] ?? 0,
      createdAt: DateTime.parse(json['createdAt'] ?? DateTime.now().toString()),
      available: json['available'] ?? true,
      soilType: json['soilType'] ?? '',
      hasWater: json['hasWater'] ?? false,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'name': name,
      'type': type,
      'area': area,
      'price': price,
      'wilaya': wilaya,
      'commune': commune,
      'description': description,
      'sellerId': sellerId,
      'sellerName': sellerName,
      'images': images,
      'rating': rating,
      'reviewsCount': reviewsCount,
      'createdAt': createdAt.toIso8601String(),
      'available': available,
      'soilType': soilType,
      'hasWater': hasWater,
    };
  }
}
