import 'package:cloud_firestore/cloud_firestore.dart';

class SupplyModel {
  final String id;
  final String name;
  final String type;
  final int quantity;
  final DateTime purchaseDate;
  final DateTime expiryDate;

  SupplyModel({
    required this.id,
    required this.name,
    required this.type,
    required this.quantity,
    required this.purchaseDate,
    required this.expiryDate,
  });

  factory SupplyModel.fromJson(Map<String, dynamic> data) {
    return SupplyModel(
      id: data['id'] ?? '',
      name: data['name'] ?? '',
      type: data['type'] ?? '',
      quantity: data['quantity'] ?? 0,
      purchaseDate: (data['purchaseDate'] as Timestamp).toDate(),
      expiryDate: (data['expiryDate'] as Timestamp).toDate(),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'name': name,
      'type': type,
      'quantity': quantity,
      'purchaseDate': purchaseDate,
      'expiryDate': expiryDate,
    };
  }
}
