class TrainingModel {
  final String id;
  final String title;
  final String description;
  final String instructor;
  final String category;
  final double price;
  final int duration; // بالساعات
  final String level; // مبتدئ، متوسط، متقدم
  final String? image;
  final double rating;
  final int reviewsCount;
  final DateTime createdAt;
  final int enrolledCount;
  final List<String> topics;

  TrainingModel({
    required this.id,
    required this.title,
    required this.description,
    required this.instructor,
    required this.category,
    required this.price,
    required this.duration,
    required this.level,
    this.image,
    this.rating = 0.0,
    this.reviewsCount = 0,
    required this.createdAt,
    this.enrolledCount = 0,
    required this.topics,
  });

  factory TrainingModel.fromJson(Map<String, dynamic> json) {
    return TrainingModel(
      id: json['id'] ?? '',
      title: json['title'] ?? '',
      description: json['description'] ?? '',
      instructor: json['instructor'] ?? '',
      category: json['category'] ?? '',
      price: (json['price'] ?? 0.0).toDouble(),
      duration: json['duration'] ?? 0,
      level: json['level'] ?? 'مبتدئ',
      image: json['image'],
      rating: (json['rating'] ?? 0.0).toDouble(),
      reviewsCount: json['reviewsCount'] ?? 0,
      createdAt: DateTime.parse(json['createdAt'] ?? DateTime.now().toString()),
      enrolledCount: json['enrolledCount'] ?? 0,
      topics: List<String>.from(json['topics'] ?? []),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'title': title,
      'description': description,
      'instructor': instructor,
      'category': category,
      'price': price,
      'duration': duration,
      'level': level,
      'image': image,
      'rating': rating,
      'reviewsCount': reviewsCount,
      'createdAt': createdAt.toIso8601String(),
      'enrolledCount': enrolledCount,
      'topics': topics,
    };
  }
}
