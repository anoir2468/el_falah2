import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/equipment_model.dart';
import '../models/worker_model.dart';
import '../models/land_model.dart';
import '../models/supply_model.dart';

class FirestoreService {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  // إضافة معدة جديدة
  Future<void> addEquipment(EquipmentModel equipment) async {
    try {
      await _firestore.collection('equipment').doc(equipment.id).set(
            equipment.toJson(),
          );
    } catch (e) {
      print('خطأ في إضافة المعدة: $e');
      rethrow;
    }
  }

  // الحصول على جميع المعدات
  Future<List<EquipmentModel>> getEquipment() async {
    try {
      QuerySnapshot snapshot = await _firestore.collection('equipment').orderBy('createdAt', descending: true).get();
      return snapshot.docs
          .map((doc) =>
              EquipmentModel.fromJson(doc.data() as Map<String, dynamic>))
          .toList();
    } catch (e) {
      print('خطأ في جلب المعدات: $e');
      rethrow;
    }
  }

  // البحث عن معدات حسب الولاية
  Future<List<EquipmentModel>> searchEquipmentByWilaya(String wilaya) async {
    try {
      QuerySnapshot snapshot = await _firestore
          .collection('equipment')
          .where('wilaya', isEqualTo: wilaya)
          .get();
      return snapshot.docs
          .map((doc) =>
              EquipmentModel.fromJson(doc.data() as Map<String, dynamic>))
          .toList();
    } catch (e) {
      print('خطأ في البحث: $e');
      rethrow;
    }
  }

  // إضافة عامل جديد
  Future<void> addWorker(WorkerModel worker) async {
    try {
      await _firestore.collection('workers').doc(worker.id).set(
            worker.toJson(),
          );
    } catch (e) {
      print('خطأ في إضافة العامل: $e');
      rethrow;
    }
  }

  // الحصول على جميع العمال
  Future<List<WorkerModel>> getWorkers() async {
    try {
      QuerySnapshot snapshot = await _firestore.collection('workers').get();
      return snapshot.docs
          .map(
              (doc) => WorkerModel.fromJson(doc.data() as Map<String, dynamic>))
          .toList();
    } catch (e) {
      print('خطأ في جلب العمال: $e');
      rethrow;
    }
  }

  // إضافة أرض جديدة
  Future<void> addLand(LandModel land) async {
    try {
      await _firestore.collection('lands').doc(land.id).set(
            land.toJson(),
          );
    } catch (e) {
      print('خطأ في إضافة الأرض: $e');
      rethrow;
    }
  }

  // الحصول على جميع الأراضي
  Future<List<LandModel>> getLands() async {
    try {
      QuerySnapshot snapshot = await _firestore.collection('lands').get();
      return snapshot.docs
          .map((doc) => LandModel.fromJson(doc.data() as Map<String, dynamic>))
          .toList();
    } catch (e) {
      print('خطأ في جلب الأراضي: $e');
      rethrow;
    }
  }

  // إضافة إمداد جديد
  Future<void> addSupply(SupplyModel supply) async {
    try {
      await _firestore.collection('supplies').doc(supply.id).set(
            supply.toJson(),
          );
    } catch (e) {
      print('خطأ في إضافة الإمداد: $e');
      rethrow;
    }
  }

  // الحصول على جميع الإمدادات
  Future<List<SupplyModel>> getSupplies() async {
    try {
      QuerySnapshot snapshot = await _firestore.collection('supplies').get();
      return snapshot.docs
          .map(
              (doc) => SupplyModel.fromJson(doc.data() as Map<String, dynamic>))
          .toList();
    } catch (e) {
      print('خطأ في جلب الإمدادات: $e');
      rethrow;
    }
  }

  // حذف إمداد
  Future<void> deleteSupply(String supplyId) async {
    try {
      await _firestore.collection('supplies').doc(supplyId).delete();
    } catch (e) {
      print('خطأ في حذف الإمداد: $e');
      rethrow;
    }
  }
}