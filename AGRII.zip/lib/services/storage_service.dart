import 'package:firebase_storage/firebase_storage.dart';
import 'dart:io';

class StorageService {
  final FirebaseStorage _storage = FirebaseStorage.instance;

  // رفع صورة واحدة
  Future<String?> uploadImage(File imageFile, String folder) async {
    try {
      String fileName = '${DateTime.now().millisecondsSinceEpoch}_${imageFile.path.split('/').last}';
      Reference ref = _storage.ref().child('$folder/$fileName');

      UploadTask uploadTask = ref.putFile(imageFile);
      TaskSnapshot snapshot = await uploadTask;

      String downloadUrl = await snapshot.ref.getDownloadURL();
      return downloadUrl;
    } catch (e) {
      print('خطأ في رفع الصورة: $e');
      rethrow;
    }
  }

  // رفع قائمة من الصور
  Future<List<String>> uploadMultipleImages(List<File> imageFiles, String folder) async {
    List<String> imageUrls = [];
    for (File file in imageFiles) {
      String? url = await uploadImage(file, folder);
      if (url != null) {
        imageUrls.add(url);
      }
    }
    return imageUrls;
  }

  // حذف صورة
  Future<void> deleteImage(String imageUrl) async {
    try {
      await _storage.refFromURL(imageUrl).delete();
    } catch (e) {
      print('خطأ في حذف الصورة: $e');
      rethrow;
    }
  }
}