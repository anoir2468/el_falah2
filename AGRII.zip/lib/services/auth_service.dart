import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/user_model.dart';

class AuthService {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  // تسجيل مستخدم جديد مع حفظ بياناته في Firestore
  Future<UserModel?> registerUser({
    required String email,
    required String password,
    required String name,
    required String phone,
    required String wilaya,
    required String commune,
    required String userType,
  }) async {
    try {
      UserCredential result = await _auth.createUserWithEmailAndPassword(
        email: email,
        password: password,
      );

      User? user = result.user;
      if (user != null) {
        UserModel newUser = UserModel(
          id: user.uid,
          name: name,
          email: email,
          phone: phone,
          wilaya: wilaya,
          commune: commune,
          userType: userType,
          createdAt: DateTime.now(),
        );

        // حفظ البيانات الإضافية في Firestore
        await _firestore.collection('users').doc(user.uid).set(newUser.toJson());
        
        // تحديث اسم المستخدم في Firebase Auth
        await user.updateDisplayName(name);
        
        return newUser;
      }
    } catch (e) {
      print('خطأ في التسجيل: $e');
      rethrow; // تمرير الخطأ ليتم معالجته في الـ Provider
    }
    return null;
  }

  // تسجيل الدخول وجلب بيانات المستخدم من Firestore
  Future<UserModel?> loginUser({
    required String email,
    required String password,
  }) async {
    try {
      UserCredential result = await _auth.signInWithEmailAndPassword(
        email: email,
        password: password,
      );

      User? user = result.user;
      if (user != null) {
        // جلب بيانات المستخدم من Firestore
        DocumentSnapshot doc = await _firestore.collection('users').doc(user.uid).get();
        if (doc.exists) {
          return UserModel.fromJson(doc.data() as Map<String, dynamic>);
        } else {
          // في حال عدم وجود بيانات في Firestore (حالة غير متوقعة)
          return UserModel(
            id: user.uid,
            name: user.displayName ?? 'مستخدم',
            email: user.email ?? '',
            phone: '',
            wilaya: '',
            commune: '',
            userType: 'farmer',
            createdAt: DateTime.now(),
          );
        }
      }
    } catch (e) {
      print('خطأ في تسجيل الدخول: $e');
      rethrow;
    }
    return null;
  }

  // تسجيل الخروج
  Future<void> logoutUser() async {
    await _auth.signOut();
  }

  // الحصول على المستخدم الحالي وبياناته
  Future<UserModel?> getCurrentUserModel() async {
    User? user = _auth.currentUser;
    if (user != null) {
      DocumentSnapshot doc = await _firestore.collection('users').doc(user.uid).get();
      if (doc.exists) {
        return UserModel.fromJson(doc.data() as Map<String, dynamic>);
      }
    }
    return null;
  }
}
