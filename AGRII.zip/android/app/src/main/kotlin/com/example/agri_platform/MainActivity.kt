package com.example.agri_platform

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
