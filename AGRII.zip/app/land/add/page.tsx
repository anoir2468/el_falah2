"use client"

import type React from "react"

import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Checkbox } from "@/components/ui/checkbox"
import { Plus, Upload, X } from "lucide-react"
import { useState } from "react"

export default function AddLandPage() {
  const [images, setImages] = useState<string[]>([])
  const [formData, setFormData] = useState({
    title: "",
    type: "",
    area: "",
    price: "",
    wilaya: "",
    commune: "",
    waterSource: "",
    soilType: "",
    description: "",
    forRent: false,
    rentPrice: "",
    features: [] as string[],
  })

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    console.log("[v0] Land submission:", formData)
  }

  const landFeatures = ["مصدر مياه", "كهرباء", "طريق معبد", "سياج", "بئر", "منزل ريفي", "مخزن", "أشجار مثمرة"]

  const toggleFeature = (feature: string) => {
    setFormData({
      ...formData,
      features: formData.features.includes(feature)
        ? formData.features.filter((f) => f !== feature)
        : [...formData.features, feature],
    })
  }

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <main className="flex-1 bg-muted/30 py-8">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          <div className="mb-6">
            <h1 className="text-3xl font-bold text-foreground mb-2">إضافة أرض زراعية</h1>
            <p className="text-muted-foreground">املأ النموذج أدناه لإضافة أرضك الزراعية للبيع أو الإيجار</p>
          </div>

          <form onSubmit={handleSubmit}>
            <Card className="p-6 mb-6">
              <h2 className="text-xl font-bold text-foreground mb-6">معلومات الأرض</h2>

              <div className="space-y-6">
                <div className="space-y-2">
                  <Label htmlFor="title">عنوان الإعلان</Label>
                  <Input
                    id="title"
                    placeholder="مثال: أرض زراعية 5 هكتار - موقع ممتاز"
                    value={formData.title}
                    onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                    required
                  />
                </div>

                <div className="grid md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <Label htmlFor="type">نوع الأرض</Label>
                    <Select value={formData.type} onValueChange={(value) => setFormData({ ...formData, type: value })}>
                      <SelectTrigger id="type">
                        <SelectValue placeholder="اختر النوع" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="agricultural">أرض زراعية</SelectItem>
                        <SelectItem value="orchard">بستان</SelectItem>
                        <SelectItem value="vineyard">كرم</SelectItem>
                        <SelectItem value="greenhouse">أرض للبيوت البلاستيكية</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="area">المساحة (هكتار)</Label>
                    <Input
                      id="area"
                      type="number"
                      step="0.1"
                      placeholder="0"
                      value={formData.area}
                      onChange={(e) => setFormData({ ...formData, area: e.target.value })}
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="price">السعر (دج)</Label>
                    <Input
                      id="price"
                      type="number"
                      placeholder="0"
                      value={formData.price}
                      onChange={(e) => setFormData({ ...formData, price: e.target.value })}
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="wilaya">الولاية</Label>
                    <Select
                      value={formData.wilaya}
                      onValueChange={(value) => setFormData({ ...formData, wilaya: value })}
                    >
                      <SelectTrigger id="wilaya">
                        <SelectValue placeholder="اختر الولاية" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="الجزائر">الجزائر</SelectItem>
                        <SelectItem value="سطيف">سطيف</SelectItem>
                        <SelectItem value="قسنطينة">قسنطينة</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="commune">البلدية</Label>
                    <Input
                      id="commune"
                      placeholder="أدخل اسم البلدية"
                      value={formData.commune}
                      onChange={(e) => setFormData({ ...formData, commune: e.target.value })}
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="waterSource">مصدر المياه</Label>
                    <Select
                      value={formData.waterSource}
                      onValueChange={(value) => setFormData({ ...formData, waterSource: value })}
                    >
                      <SelectTrigger id="waterSource">
                        <SelectValue placeholder="اختر مصدر المياه" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="well">بئر</SelectItem>
                        <SelectItem value="river">نهر</SelectItem>
                        <SelectItem value="irrigation">شبكة ري</SelectItem>
                        <SelectItem value="none">لا يوجد</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="soilType">نوع التربة</Label>
                    <Select
                      value={formData.soilType}
                      onValueChange={(value) => setFormData({ ...formData, soilType: value })}
                    >
                      <SelectTrigger id="soilType">
                        <SelectValue placeholder="اختر نوع التربة" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="clay">طينية</SelectItem>
                        <SelectItem value="sandy">رملية</SelectItem>
                        <SelectItem value="loamy">طميية</SelectItem>
                        <SelectItem value="mixed">مختلطة</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label>المميزات</Label>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    {landFeatures.map((feature) => (
                      <div key={feature} className="flex items-center gap-2">
                        <Checkbox
                          id={feature}
                          checked={formData.features.includes(feature)}
                          onCheckedChange={() => toggleFeature(feature)}
                        />
                        <Label htmlFor={feature} className="text-sm cursor-pointer">
                          {feature}
                        </Label>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="description">الوصف</Label>
                  <Textarea
                    id="description"
                    placeholder="اكتب وصفاً تفصيلياً للأرض، الموقع، المحاصيل المناسبة، إلخ..."
                    rows={6}
                    value={formData.description}
                    onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                    required
                  />
                </div>

                <div className="space-y-4 pt-4 border-t border-border">
                  <div className="flex items-center gap-2">
                    <Checkbox
                      id="forRent"
                      checked={formData.forRent}
                      onCheckedChange={(checked) => setFormData({ ...formData, forRent: checked as boolean })}
                    />
                    <Label htmlFor="forRent" className="cursor-pointer">
                      متاح للإيجار
                    </Label>
                  </div>

                  {formData.forRent && (
                    <div className="space-y-2 mr-6">
                      <Label htmlFor="rentPrice">سعر الإيجار (دج/سنة)</Label>
                      <Input
                        id="rentPrice"
                        type="number"
                        placeholder="0"
                        value={formData.rentPrice}
                        onChange={(e) => setFormData({ ...formData, rentPrice: e.target.value })}
                      />
                    </div>
                  )}
                </div>
              </div>
            </Card>

            <Card className="p-6 mb-6">
              <h2 className="text-xl font-bold text-foreground mb-6">الصور</h2>
              <div className="space-y-4">
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  {images.map((image, index) => (
                    <div
                      key={index}
                      className="relative aspect-square rounded-lg border-2 border-border overflow-hidden"
                    >
                      <img
                        src={image || "/placeholder.svg"}
                        alt={`صورة ${index + 1}`}
                        className="w-full h-full object-cover"
                      />
                      <Button
                        type="button"
                        variant="destructive"
                        size="icon"
                        className="absolute top-2 left-2 h-8 w-8"
                        onClick={() => setImages(images.filter((_, i) => i !== index))}
                      >
                        <X className="h-4 w-4" />
                      </Button>
                    </div>
                  ))}
                  <button
                    type="button"
                    className="aspect-square rounded-lg border-2 border-dashed border-border hover:border-[#2d7a3e] hover:bg-muted/50 transition-colors flex flex-col items-center justify-center gap-2 cursor-pointer"
                  >
                    <Upload className="h-8 w-8 text-muted-foreground" />
                    <span className="text-sm text-muted-foreground">إضافة صورة</span>
                  </button>
                </div>
                <p className="text-sm text-muted-foreground">يمكنك إضافة حتى 10 صور للأرض</p>
              </div>
            </Card>

            <div className="flex gap-4">
              <Button type="submit" className="flex-1 bg-[#2d7a3e] hover:bg-[#1f5a2d] h-11">
                <Plus className="h-5 w-5 ml-2" />
                نشر الإعلان
              </Button>
              <Button type="button" variant="outline" className="h-11 bg-transparent">
                إلغاء
              </Button>
            </div>
          </form>
        </div>
      </main>
      <Footer />
    </div>
  )
}
