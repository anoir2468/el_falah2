"use client"

import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Menu, User, ShoppingCart, Plus } from "lucide-react"
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from "@/components/ui/sheet"

export function Header() {
  const navigation = [
    { name: "الرئيسية", href: "/" },
    { name: "المعدات", href: "/equipment" },
    { name: "العمال", href: "/workers" },
    { name: "التكوين", href: "/training" },
    { name: "الأراضي", href: "/land" },
    { name: "المنشآت", href: "/facilities" },
    { name: "الأدوية والأسمدة", href: "/supplies" },
  ]

  const quickAddItems = [
    { name: "إضافة معدة", href: "/equipment/add", icon: "🚜" },
    { name: "إضافة ملف عامل", href: "/workers/add", icon: "👨‍🌾" },
    { name: "إضافة أرض", href: "/land/add", icon: "🌾" },
    { name: "إضافة منشأة", href: "/facilities/add", icon: "🏭" },
    { name: "إضافة منتج", href: "/supplies/add", icon: "🧪" },
  ]

  return (
    <header className="bg-white border-b border-border sticky top-0 z-50 shadow-sm">
      <nav className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="flex h-16 items-center justify-between">
          {/* Logo */}
          <Link href="/" className="flex items-center gap-2">
            <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-[#2d7a3e] to-[#10b981] flex items-center justify-center">
              <span className="text-white font-bold text-xl">ف</span>
            </div>
            <div className="flex flex-col">
              <span className="font-bold text-lg text-foreground leading-none">منصة الفلاح</span>
              <span className="text-xs text-muted-foreground">الجزائري</span>
            </div>
          </Link>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center gap-1">
            {navigation.map((item) => (
              <Link
                key={item.name}
                href={item.href}
                className="px-3 py-2 text-sm font-medium text-muted-foreground hover:text-foreground hover:bg-muted rounded-md transition-colors"
              >
                {item.name}
              </Link>
            ))}
          </div>

          {/* Actions */}
          <div className="flex items-center gap-2">
            <Sheet>
              <SheetTrigger asChild>
                <Button variant="ghost" size="icon" className="hidden lg:flex" title="إضافة إعلان">
                  <Plus className="h-5 w-5" />
                </Button>
              </SheetTrigger>
              <SheetContent side="right">
                <SheetHeader>
                  <SheetTitle>إضافة جديد</SheetTitle>
                </SheetHeader>
                <div className="mt-6 flex flex-col gap-2">
                  {quickAddItems.map((item) => (
                    <Link key={item.name} href={item.href}>
                      <Button variant="outline" className="w-full justify-start h-12 text-base bg-transparent">
                        <span className="text-2xl ml-3">{item.icon}</span>
                        {item.name}
                      </Button>
                    </Link>
                  ))}
                </div>
              </SheetContent>
            </Sheet>

            <Button variant="ghost" size="icon" className="hidden sm:flex">
              <ShoppingCart className="h-5 w-5" />
            </Button>
            <Link href="/auth/login">
              <Button variant="outline" size="sm" className="hidden sm:flex bg-transparent">
                <User className="h-4 w-4 ml-2" />
                تسجيل الدخول
              </Button>
            </Link>
            <Link href="/auth/register">
              <Button size="sm" className="hidden sm:flex bg-[#2d7a3e] hover:bg-[#1f5a2d]">
                إنشاء حساب
              </Button>
            </Link>

            <Sheet>
              <SheetTrigger asChild>
                <Button variant="ghost" size="icon" className="md:hidden">
                  <Menu className="h-6 w-6" />
                </Button>
              </SheetTrigger>
              <SheetContent side="right" className="w-[300px]">
                <SheetHeader>
                  <SheetTitle>القائمة</SheetTitle>
                </SheetHeader>
                <div className="mt-6 flex flex-col gap-2">
                  {navigation.map((item) => (
                    <Link key={item.name} href={item.href}>
                      <Button variant="ghost" className="w-full justify-start">
                        {item.name}
                      </Button>
                    </Link>
                  ))}
                  <div className="flex flex-col gap-2 mt-4 pt-4 border-t border-border">
                    <Link href="/auth/login">
                      <Button variant="outline" size="sm" className="w-full bg-transparent">
                        <User className="h-4 w-4 ml-2" />
                        تسجيل الدخول
                      </Button>
                    </Link>
                    <Link href="/auth/register">
                      <Button size="sm" className="w-full bg-[#2d7a3e] hover:bg-[#1f5a2d]">
                        إنشاء حساب
                      </Button>
                    </Link>
                  </div>
                </div>
              </SheetContent>
            </Sheet>
          </div>
        </div>
      </nav>
    </header>
  )
}
